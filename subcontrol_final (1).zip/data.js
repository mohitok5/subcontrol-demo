const beneficios=[
 {icon:"https://dummyimage.com/40x40/ffd700/000.png",title:"Detecta todas tus suscripciones",description:"Encuentra automáticamente todas tus suscripciones activas."},
 {icon:"https://dummyimage.com/40x40/ffd700/000.png",title:"Ahorra dinero",description:"Identifica pagos innecesarios y cancélalos fácilmente."},
 {icon:"https://dummyimage.com/40x40/ffd700/000.png",title:"Seguridad total",description:"Tus datos están protegidos con cifrado de nivel bancario."}
];
const planes=[
 {name:"Básico",price:"Gratis",features:["Detección automática","Panel de control","Alertas de renovación"]},
 {name:"Premium",price:"5€/mes",features:["Todo lo del Básico","Cancelación automática","Historial de gastos"]}
];
const faqs=[
 {question:"¿Cómo funciona?",answer:"Analizamos tus emails y movimientos bancarios con tu permiso."},
 {question:"¿Es seguro?",answer:"Usamos cifrado de nivel bancario y nunca compartimos tu información."}
];
