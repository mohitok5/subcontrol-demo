
// -------- Renderizado dinámico --------
function renderList(id, data, template) {
  const container = document.getElementById(id);
  data.forEach(item => {
    const el = document.createElement('div');
    el.innerHTML = template(item);
    container.appendChild(el);
  });
}

renderList("benefit-list", beneficios, b =>
  `<div class="benefit-card"><img src="${b.icon}"><h3>${b.title}</h3><p>${b.description}</p></div>`
);
renderList("pricing-cards", planes, p =>
  `<div class="pricing-card"><h3>${p.name}</h3><p class="price">${p.price}</p><ul>${p.features.map(f=>`<li>${f}</li>`).join('')}</ul></div>`
);
renderList("faq-list", faqs, f =>
  `<div class="faq-item"><h4>${f.question}</h4><p>${f.answer}</p></div>`
);

// -------- VANTA Animaciones --------
function initVantaBackground(elementId, initialColor) {
  return VANTA.NET({
    el: elementId,
    mouseControls: true,
    touchControls: true,
    gyroControls: false,
    minHeight: 200.00,
    minWidth: 200.00,
    scale: 1.00,
    scaleMobile: 1.00,
    color: initialColor,
    backgroundColor: 0x0f1116,
    points: 12.00,
    maxDistance: 20.00,
    spacing: 15.00,
    mouseEase: 0.15,
    zoom: 1.1
  });
}

// Inicialización con colores base
let heroVanta = initVantaBackground("#hero", 0xffd700);
let pricingVanta = initVantaBackground("#pricing-section", 0x00bfff);
let footerVanta = initVantaBackground("#footer-section", 0x00ffcc);

// Interpolación de colores suave
function lerpColor(a, b, amount) {
  const ar = (a >> 16) & 0xff, ag = (a >> 8) & 0xff, ab = a & 0xff;
  const br = (b >> 16) & 0xff, bg = (b >> 8) & 0xff, bb = b & 0xff;
  const rr = ar + amount * (br - ar);
  const rg = ag + amount * (bg - ag);
  const rb = ab + amount * (bb - ab);
  return ((rr << 16) | (rg << 8) | (rb | 0));
}

const colors = {
  hero: 0xffd700,
  pricing: 0x00bfff,
  footer: 0x00ffcc
};

let currentColorHero = colors.hero;
let currentColorPricing = colors.pricing;
let currentColorFooter = colors.footer;

let targetColorHero = colors.hero;
let targetColorPricing = colors.pricing;
let targetColorFooter = colors.footer;

let mouseIntensity = 0;

// Movimiento del ratón para brillo y parallax
document.addEventListener("mousemove", (e) => {
  const centerX = window.innerWidth / 2;
  const centerY = window.innerHeight / 2;
  const distX = (e.clientX - centerX) / centerX;
  const distY = (e.clientY - centerY) / centerY;

  mouseIntensity = Math.max(Math.abs(distX), Math.abs(distY));

  // Parallax extra
  [heroVanta, pricingVanta, footerVanta].forEach(vanta => {
    if (vanta && vanta.camera) {
      vanta.camera.position.x = distX * 5;
      vanta.camera.position.y = -distY * 5;
    }
  });
});

// Detectar sección visible
document.addEventListener("scroll", () => {
  const scrollY = window.scrollY;
  const viewportHeight = window.innerHeight;

  if (scrollY < viewportHeight) {
    targetColorHero = colors.hero;
  } else if (scrollY >= viewportHeight && scrollY < viewportHeight * 2.5) {
    targetColorPricing = colors.pricing;
  } else {
    targetColorFooter = colors.footer;
  }
});

// Función para brillo según intensidad
function brightenColor(color, intensity) {
  const r = Math.min(255, ((color >> 16) & 0xff) + intensity * 50);
  const g = Math.min(255, ((color >> 8) & 0xff) + intensity * 50);
  const b = Math.min(255, (color & 0xff) + intensity * 50);
  return ((r << 16) | (g << 8) | b);
}

// Animación continua
function animateColors() {
  currentColorHero = lerpColor(currentColorHero, targetColorHero, 0.02);
  currentColorPricing = lerpColor(currentColorPricing, targetColorPricing, 0.02);
  currentColorFooter = lerpColor(currentColorFooter, targetColorFooter, 0.02);

  heroVanta.setOptions({ color: brightenColor(currentColorHero, mouseIntensity) });
  pricingVanta.setOptions({ color: brightenColor(currentColorPricing, mouseIntensity) });
  footerVanta.setOptions({ color: brightenColor(currentColorFooter, mouseIntensity) });

  requestAnimationFrame(animateColors);
}
animateColors();
